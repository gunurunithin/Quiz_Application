const data = [
    {
        question: 'What is the national animal of India?',
        options: ['Tiger', 'Lion', 'Dog', 'Bear'],
        answer: 0
    },
    {
        question: 'What is the national flower of India?',
        options: ['Lotus', 'Rose', 'Lily', 'Jasmine'],
        answer: 0
    },
    {
        question: 'What is the national bird of India?',
        options: ['Peacock', 'Parrot', 'Eagle', 'Sparrow'],
        answer: 0
    },
    {
        question: 'What is the national sport of india?',
        options: ['Hockey', 'Cricket', 'Badminton', 'Kabaddi'],
        answer: 0
    },
    {
        question: 'What is the currency of India?',
        options: ['Rupee', 'Dollar', 'Euro', 'Chinese Yuan'],
        answer: 0
    }
];

const quiz = document.getElementById('quiz');
const questionEl = document.getElementById('question');
const option0El = document.getElementById('option0');
const option1El = document.getElementById('option1');
const option2El = document.getElementById('option2');
const option3El = document.getElementById('option3');
const submitBtn = document.getElementById('submit');
const scoreEl = document.getElementById('score');
const restartBtn = document.getElementById('restart');

let presentQues = 0;
let score = 0;

function loadQuestion() {
    const currentQuizData = data[presentQues];

    questionEl.innerText = currentQuizData.question;
    option0El.innerText = currentQuizData.options[0];
    option1El.innerText = currentQuizData.options[1];
    option2El.innerText = currentQuizData.options[2];
    option3El.innerText = currentQuizData.options[3];
}

function getSelected() {
    const answerEls = document.getElementsByName('answer');

    let answer;

    answerEls.forEach((answerEl) => {
        if (answerEl.checked) {
            answer = answerEl.value;
        }
    });

    return answer;
}

function deselectAnswers() {
    const answerEls = document.getElementsByName('answer');
    answerEls.forEach((answerEl) => {
        answerEl.checked = false;
    });
}

loadQuestion();

submitBtn.addEventListener('click', () => {
    const answer = getSelected();

    if (answer === undefined) {
        alert('Please select an answer');
        return;
    }

    if (answer == data[presentQues].answer) {
        score++;
    }

    presentQues++;

    if (presentQues < data.length) {
        loadQuestion();
        deselectAnswers();
    } else {
        quiz.innerHTML = `
            <h2>You answered ${score}/${data.length} questions correctly</h2>
        `;

        restartBtn.style.display = 'block';
    }
});

restartBtn.addEventListener('click', () => {
    location.reload();
});
